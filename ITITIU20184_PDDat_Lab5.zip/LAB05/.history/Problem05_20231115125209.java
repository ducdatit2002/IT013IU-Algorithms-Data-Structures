public class Problem05 {
    
}
