
public class HashTable {

  public int insert(int key) {
    return 0;
  }

  public int find(int key) {
    return 0;
  }

  public double getSize() {
    return 0;
  }

  public double getCapacity() {
    return 0;
  }

}
