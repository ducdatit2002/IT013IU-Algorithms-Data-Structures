import java.io.*;

// Class for Data Items
class DataItem {
    private int iData; // data item (key)

    // Constructor
    public DataItem(int ii) {
        iData = ii;
    }

    // Method to get key
    public int getKey() {
        return iData;
    }
}

// Class for Hash Table
class HashTable {
    private DataItem[] hashArray; // Array for the hash table
    private int arraySize;
    private DataItem nonItem; // Placeholder for deleted items

    // Constructor
    public HashTable(int size) {
        arraySize = size;
        hashArray = new DataItem[arraySize];
        nonItem = new DataItem(-1);
    }

    // Method to display the table
    public void displayTable() {
        System.out.print("Table: ");
        for (int j = 0; j < arraySize; j++) {
            if (hashArray[j] != null) {
                System.out.print(hashArray[j].getKey() + " ");
            } else {
                System.out.print("** ");
            }
        }
        System.out.println("");
    }

    // Hash Function 1
    public int hashFunc1(int key) {
        return key % arraySize;
    }

    // Hash Function 2
    public int hashFunc2(int key) {
        // non-zero, less than array size, different from hF1
        // array size must be relatively prime to 5, 4, 3, and 2
        return 5 - key % 5;
    }

    // Method to insert a DataItem
    public void insert(int key, DataItem item) {
        int hashVal = hashFunc1(key); // Hash the key
        int stepSize = hashFunc2(key); // Get step size

        // Finding the correct position to insert
        while (hashArray[hashVal] != null && hashArray[hashVal].getKey() != -1) {
            hashVal += stepSize; // Add the step for wraparound
            hashVal %= arraySize;
        }
        hashArray[hashVal] = item; // Insert item
    }

    // Method to delete a DataItem
    public DataItem delete(int key) {
        int hashVal = hashFunc1(key); // Hash the key
        int stepSize = hashFunc2(key); // Get step size

        while (hashArray[hashVal] != null) { // Until empty cell
            if (hashArray[hashVal].getKey() == key) {
                DataItem temp = hashArray[hashVal]; // Save item
                hashArray[hashVal] = nonItem; // Delete item
                return temp; // Return item
            }
            hashVal += stepSize; // Add the step for wraparound
            hashVal %= arraySize;
        }
        return null; // Can't find item
    }

    // Method to find a DataItem
    public DataItem find(int key) {
        int hashVal = hashFunc1(key); // Hash the key
        int stepSize = hashFunc2(key); // Get step size

        while (hashArray[hashVal] != null) { // Until empty cell
            if (hashArray[hashVal].getKey() == key) {
                return hashArray[hashVal]; // Item found, return it
            }
            hashVal += stepSize; // Add the step for wraparound
            hashVal %= arraySize;
        }
        return null; // Can't find item
    }
}

// Main class for Hash Table Application
class HashDoubleApp {
    public static void main(String[] args) throws IOException {
        int aKey;
        DataItem aDataItem;
        int size, n;

        // Get sizes from user
        System.out.print("Enter size of hash table: ");
        size = getInt();
        System.out.print("Enter initial number of items: ");
        n = getInt();

        // Create hash table
        HashTable theHashTable = new HashTable(size);

        // Insert data into the table
        for (int j = 0; j < n; j++) {
            aKey = (int) (java.lang.Math.random() * 2 * size);
            aDataItem = new DataItem(aKey);
            theHashTable.insert(aKey, aDataItem);
        }

        // Interacting with the user
        while (true) {
            System.out.print("Enter first letter of show, insert, delete, or find: ");
            char choice = getChar();
            switch (choice) {
                case 's':
                    theHashTable.displayTable();
                    break;
                case 'i': // Insert
                    System.out.print("Enter key value to insert: ");
                    aKey = getInt();
                    aDataItem = new DataItem(aKey);
                    theHashTable.insert(aKey, aDataItem);
                    break;

                case 'd': // Delete
                    System.out.print("Enter key value to delete: ");
                    aKey = getInt();
                    theHashTable.delete(aKey);
                    break;

                case 'f': // Find
                    System.out.print("Enter key value to find: ");
                    aKey = getInt();
                    aDataItem = theHashTable.find(aKey);
                    if (aDataItem != null) {
                        System.out.println("Found " + aKey);
                    } else {
                        System.out.println("Could not find " + aKey);
                    }
                    break;

                default:
                    System.out.print("Invalid entry\n");
            } // end switch
        } // end while
    } // end main()

    // Method to read a string from the user
    public static String getString() throws IOException {
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);
        return br.readLine();
    }

    // Method to read a character from the user
    public static char getChar() throws IOException {
        String s = getString();
        return s.charAt(0);
    }

    // Method to read an integer from the user
    public static int getInt() throws IOException {
        String s = getString();
        return Integer.parseInt(s);
    }
} // end class HashDoubleApp
            
