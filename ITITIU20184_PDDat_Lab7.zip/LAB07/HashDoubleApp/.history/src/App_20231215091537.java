// hashDouble.java
// demonstrates hash table with double hashing
// to run this program: C:>java HashDoubleApp
import java.io.*; //////////////////////////////////////////////////////////////// class DataItem
{ // (could have more items)
private int iData; // data item (key) //--------------------------------------------------------------
public DataItem(int ii) // constructor { iData = ii; }
//-------------------------------------------------------------- public int getKey()
{ return iData; } //--------------------------------------------------------------
} // end class DataItem //////////////////////////////////////////////////////////////// class HashTable
{
private DataItem[] hashArray; // array is the hash table private int arraySize;
private DataItem nonItem; // for deleted items
// ------------------------------------------------------------- HashTable(int size) // constructor
{
arraySize = size;
hashArray = new DataItem[arraySize]; nonItem = new DataItem(-1);
}
// ------------------------------------------------------------- public void displayTable()
{
System.out.print(“Table: “); for(int j=0; j<arraySize; j++)
