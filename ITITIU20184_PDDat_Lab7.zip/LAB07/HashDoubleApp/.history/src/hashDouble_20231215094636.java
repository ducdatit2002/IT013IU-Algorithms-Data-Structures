import java.io.*;

// Inside the HashTable class
public DataItem delete(int key) {
    int hashVal = hashFunc1(key);
    int stepSize = hashFunc2(key);
    int probes = 0;

    while (hashArray[hashVal] != null) {
        if (hashArray[hashVal].getKey() == key) {
            DataItem temp = hashArray[hashVal];
            hashArray[hashVal] = nonItem; // Mark deleted
            System.out.println("Deleting key " + key + ": HashVal=" + hashVal + ", StepSize=" + stepSize + ", Probes=" + probes);
            return temp;
        }
        hashVal += stepSize;
        hashVal %= arraySize;
        probes++;
    }
    System.out.println("Deleting key " + key + ": Not Found, Probes=" + probes);
    return null;
}


class HashTable {
    private DataItem[] hashArray;
    private int arraySize;
    private DataItem nonItem;
    private int totalProbesForInsert = 0;
    private int insertCount = 0;

    public HashTable(int size) {
        arraySize = size;
        hashArray = new DataItem[arraySize];
        nonItem = new DataItem(-1);
    }

    public void displayTable() {
        System.out.print("Table: ");
        for (int j = 0; j < arraySize; j++) {
            if (hashArray[j] != null) System.out.print(hashArray[j].getKey() + " ");
            else System.out.print("** ");
        }
        System.out.println("");
    }

    public int hashFunc1(int key) { return key % arraySize; }
    public int hashFunc2(int key) { return 5 - key % 5; }

    public void insert(int key, DataItem item) {
        int hashVal = hashFunc1(key);
        int stepSize = hashFunc2(key);
        int probes = 0;

        while (hashArray[hashVal] != null && hashArray[hashVal].getKey() != -1) {
            hashVal += stepSize;
            hashVal %= arraySize;
            probes++;
        }

        hashArray[hashVal] = item;
        totalProbesForInsert += probes;
        insertCount++;
        System.out.println("Inserting key " + key + ": HashVal=" + hashVal + ", StepSize=" + stepSize + ", Probes=" + probes);
    }

    public DataItem find(int key) {
        int hashVal = hashFunc1(key);
        int stepSize = hashFunc2(key);
        int probes = 0;

        while (hashArray[hashVal] != null) {
            if (hashArray[hashVal].getKey() == key) {
                System.out.println("Finding key " + key + ": HashVal=" + hashVal + ", StepSize=" + stepSize + ", Probes=" + probes);
                return hashArray[hashVal];
            }
            hashVal += stepSize;
            hashVal %= arraySize;
            probes++;
        }
        System.out.println("Finding key " + key + ": Not Found, Probes=" + probes);
        return null;
    }

    public float getAverageProbeLength() {
        return (float)totalProbesForInsert / insertCount;
    }

    public float getLoadFactor() {
        int itemCount = 0;
        for (DataItem item : hashArray) {
            if (item != null && item.getKey() != -1) itemCount++;
        }
        return (float)itemCount / arraySize;
    }
}

class HashDoubleApp {
    public static void main(String[] args) throws IOException {
        int aKey;
        DataItem aDataItem;
        int size, n;

        System.out.print("Enter size of hash table: ");
        size = getInt();
        System.out.print("Enter initial number of items: ");
        n = getInt();

        HashTable theHashTable = new HashTable(size);

        System.out.println("Initial Table Filling:");
        for (int j = 0; j < n; j++) {
            aKey = (int) (java.lang.Math.random() * 2 * size);
            aDataItem = new DataItem(aKey);
            theHashTable.insert(aKey, aDataItem);
        }

        theHashTable.displayTable();
        System.out.println("Average Probe Length for Initial Filling: " + theHashTable.getAverageProbeLength());
        System.out.println("Load Factor: " + theHashTable.getLoadFactor());

        while (true) {
            System.out.print("Enter first letter of show, insert, delete, or find: ");
            char choice = getChar();
            switch (choice) {
                case 's':
                    theHashTable.displayTable();
                    break;
                case 'i':
                    System.out.print("Enter key value to insert: ");
                    aKey = getInt();
                    aDataItem = new DataItem(aKey);
                    theHashTable.insert(aKey, aDataItem);
                    break;
                case 'd':
                    System.out.print("Enter key value to delete: ");
                    aKey = getInt();
                    theHashTable.delete(aKey);
                    break;
                case 'f':
                    System.out.print("Enter key value to find: ");
                    aKey = getInt();
                    aDataItem = theHashTable.find(aKey);
                    if (aDataItem != null) {
                        System.out.println("Found " + aKey);
                    } else {
                        System.out.println("Could not find " + aKey);
                    }
                    break;

                default:
                    System.out.print("Invalid entry\n");
            } // end switch
        } // end while
    } // end main()

    // Method to read a string from the user
    public static String getString() throws IOException {
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);
        return br.readLine();
    }

    // Method to read a character from the user
    public static char getChar() throws IOException {
        String s = getString();
        return s.charAt(0);
    }

    // Method to read an integer from the user
    public static int getInt() throws IOException {
        String s = getString();
        return Integer.parseInt(s);
    }
} // end class HashDoubleApp

