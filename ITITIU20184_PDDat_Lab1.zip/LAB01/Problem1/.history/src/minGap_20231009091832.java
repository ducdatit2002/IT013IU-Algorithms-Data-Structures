public class minGap {
    
}
