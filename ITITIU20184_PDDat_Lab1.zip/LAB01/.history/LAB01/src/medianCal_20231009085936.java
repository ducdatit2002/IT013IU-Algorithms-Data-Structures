public class medianCal {
    
}
