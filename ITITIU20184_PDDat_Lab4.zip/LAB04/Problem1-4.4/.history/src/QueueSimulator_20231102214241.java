public class QueueSimulator {
    
}
