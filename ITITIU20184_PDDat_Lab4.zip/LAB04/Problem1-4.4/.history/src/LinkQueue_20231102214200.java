public class LinkQueue {
    
}
